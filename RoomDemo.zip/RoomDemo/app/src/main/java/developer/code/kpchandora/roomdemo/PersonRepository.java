package developer.code.kpchandora.roomdemo;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;
import android.util.Log;

import java.util.List;

public class PersonRepository {

    private static final String TAG = "PersonRepository";
    
    private PersonDao personDao;
    private LiveData<List<Person>>allPersonList;

    PersonRepository(Application application){
        PersonDatabase database = PersonDatabase.getDatabase(application);
        personDao = database.personDao();
        allPersonList = personDao.getAllPerson();
    }

    LiveData<List<Person>>getAllPersonList(){
        Log.i(TAG, "getAllPersonList: ");
        return allPersonList;
    }


    public void insert(Person person){
        Log.i(TAG, "insert: ");
        new InsertAsynTask(personDao).execute(person);
    }

    private static class InsertAsynTask extends AsyncTask<Person, Void, Void>{

        private PersonDao personDao;

        InsertAsynTask(PersonDao dao){
            personDao = dao;
        }

        @Override
        protected Void doInBackground(Person... people) {
            Log.i(TAG, "doInBackground: ");
            personDao.insert(people[0]);
            return null;
        }
    }

}
