package developer.code.kpchandora.roomdemo;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;
import android.util.Log;

import java.util.List;

public class PersonViewModel extends AndroidViewModel {

    private static final String TAG = "PersonViewModel";
    
    private PersonRepository repository;
    private LiveData<List<Person>> listLiveData;

    public PersonViewModel(@NonNull Application application) {
        super(application);
        repository = new PersonRepository(application);
        listLiveData = repository.getAllPersonList();
    }

    public LiveData<List<Person>> getAllData() {
        Log.i(TAG, "getAllData: ");
        return listLiveData;
    }

    public void insert(Person person){
        Log.i(TAG, "insert: ");
        repository.insert(person);
    }

}
