package developer.code.kpchandora.roomdemo;


import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

@Dao
public interface PersonDao {

    @Insert
    void insert(Person person);

    @Update
    void updatePerson(Person... people);

    @Query("DELETE FROM " + DbUtils.PERSON_TABLE_NAME)
    void deleteAll();

    @Query("SELECT * FROM " + DbUtils.PERSON_TABLE_NAME + " ORDER BY " + DbUtils.PERSON_ID + " ASC")
    LiveData<List<Person>> getAllPerson();

//    @Query("SELECT * FROM " + DbUtils.PERSON_TABLE_NAME + " WHERE " + DbUtils.PERSON_ID + " LIKE :" + DbUtils.PERSON_ID)
//    List<Person> findPerson(int id);
}
